import React from 'react'

export default function Navbar() {
  return (
    <div className='navbar'>
          <a href="">Парикмахерская</a>
          <a href="">Барбершоп</a>
          <a href="">Маникюр</a>
          <a href="">Педикюр</a>
          <a href="">Массаж</a>
          <a href="">Мебель</a>
    </div>
  )
}
