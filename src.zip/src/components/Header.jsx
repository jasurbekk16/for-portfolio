import React, { useState } from 'react';
import logo from "../assets/header/logo.png";

export default function Header({ newdata }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false)
  const toggle = () => {
    setOpen(!open);
    console.log(open);
  };

  const basket = JSON.parse(localStorage.getItem('basket')) || [];
//plus
function plus(id){
basket.map((item)=>{
  if(item.id === id){
    item.count++
    localStorage.setItem('basket', JSON.stringify(basket))
  }
})
setLoading(true)
setTimeout(()=>{
  setLoading(false)
}, 20)
}
//minus
function minus(id){
basket.map((item)=>{
  if(item.id === id){
    if(item.count > 1){
      item.count--
      localStorage.setItem('basket', JSON.stringify(basket))
    }
  }
})
setLoading(true)
setTimeout(()=>{
  setLoading(false)
}, 20)
}
  return (
    <div className='header'>
      <div className="h-left">
        <img src={logo} alt="" />
        <p>BEAUTY</p>
      </div>
      <div className="h-right">
        <a href="tel:8 (812) 123-45-67">8 (812) 123-45-67</a>
        <button>Обратный звонок</button>
      </div>

      <div className="basketbox">
        <button onClick={toggle} id='basket'>basket</button>
      </div>

      <div className="modal" style={open ? { transform: "translateX(0)" } : { transform: "translateX(500px)" }}>
        {
          basket.map((item) => (
            <div className="modal-item" key={item.id}>
              <img src={item.img} alt="" />
              <p>{item.name}</p>
              <b>{item.price} ₽</b>
              <div>
                <button onClick={()=> minus(item.id)}>-</button>
                <p>{item.count}</p>
                <button onClick={()=> plus(item.id)}>+</button>
              </div>

            </div>
          ))
        }
      </div>
    </div>
  );
}
