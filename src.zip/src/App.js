import React from "react";
import Main from "./components/Main";

function App() {
  return (
    <div className="App">
      <Main newdata="basket" />
    </div>
  );
}

export default App;
